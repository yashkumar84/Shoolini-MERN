import { useDispatch } from "react-redux";
import { decrement, increment } from "../redux/counterSlice";

const CounterButtons = () => {
  const dispatch = useDispatch();
  return (
    <div>
      <button onClick={() => dispatch(increment())}>+</button>
      <button onClick={() => dispatch(decrement())}>-</button>
    </div>
  );
};

export default CounterButtons;
