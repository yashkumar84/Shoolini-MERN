import CounterButtons from "../components/CounterButtons";
import CounterDisplay from "../components/CounterDisplay";

const HomePage = () => {
  return (
    <div>
      <CounterDisplay />
      <CounterButtons />
    </div>
  );
};

export default HomePage;
