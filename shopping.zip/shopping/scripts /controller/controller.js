import { getData } from "../services/api-client.js";

window.addEventListener("load", init);
let data;
async function init() {
  data = await getData();
  printCarousel();
}

function printCarousel() {
  let carousel = `<div id="carouselExampleFade" class="carousel slide carousel-fade">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>`;
  let container = document.querySelector(".container-1");
  console.log(container);
  // container.innerHTML += carousel;
}
