export async function getData() {
  let response = await fetch("https://api.escuelajs.co/api/v1/products");
  let data = await response.json();
  console.log(data[0].images[2]);
  return data;
}
