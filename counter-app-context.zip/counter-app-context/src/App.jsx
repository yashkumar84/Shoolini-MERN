import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import CounterDisplay from "./components/CounterDisplay";
import CounterButtons from "./components/CounterButtons";
import ImportantComponent from "./components/importantComponent";

function App() {
  const [number, setNumber] = useState(1);
  const increment = () => {
    setNumber((prev) => prev + 1);
  };
  // return (
  //   <>
  //     <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
  //       <div className="bg-white p-8 rounded-lg shadow-md">
  //         <h1 className="text-3xl font-bold mb-6 text-center">Counter App</h1>
  //         <CounterDisplay />
  //         <CounterButtons />
  //       </div>
  //     </div>
  //   </>
  // );
  return (
    <>
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <ImportantComponent number={number} />
          <button onClick={increment}>increment</button>
        </div>
      </div>
    </>
  );
}

export default App;
