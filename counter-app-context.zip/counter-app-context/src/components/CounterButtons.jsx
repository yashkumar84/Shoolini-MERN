import { useCounter } from "../context/counterContext";

const CounterButtons = () => {
  const { increment, decrement } = useCounter();
  return (
    <div className="flex gap-4">
      <button
        className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition-colors"
        onClick={increment}
      >
        +
      </button>
      <button
        className="bg-red-500 text-white px-6 py-2 rounded hover:bg-red-600 transition-colors"
        onClick={decrement}
      >
        -
      </button>
    </div>
  );
};

export default CounterButtons;
