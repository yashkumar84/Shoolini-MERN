import { useCounter } from "../context/counterContext";

const CounterDisplay = () => {
  const { count } = useCounter();
  return <div className="text-6xl font-bold mb-6 text-gray-800">{count}</div>;
};

export default CounterDisplay;
