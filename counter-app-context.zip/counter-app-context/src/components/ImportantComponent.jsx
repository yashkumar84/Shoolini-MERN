import { useMemo } from "react";

const ImportantComponent = ({ number }) => {
  const compute = useMemo(() => {
    console.log("Recalculate ......");
    let result = 0;
    for (let i = 0; i < 1000000; i++) {
      result += number;
    }
    return result;
  }, [number]);
  return (
    <div>
      <h1>Coumputed Value : {compute}</h1>
    </div>
  );
};

export default ImportantComponent;
