import { useState } from "react";

import "./App.css";

function App() {
  const [isLoggedin, setIsLoggedin] = useState(true);
  return <>{isLoggedin ? <h1>Logged in </h1> : <h1>Not Logged in </h1>}</>;
}

export default App;
