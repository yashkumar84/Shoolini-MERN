import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import connectDB from "./src/shared/db/connection.js";
import { userRouter } from "./src/routes/v1/user-routes.js";
import { taskRouter } from "./src/routes/v1/task-routes.js";

const app = express();
dotenv.config();
app.use(cors());
app.use(express.json());

connectDB();

app.use("/users", userRouter);
app.use("/tasks", taskRouter);

app.listen(process.env.PORT || 4000, () =>
  console.log(`Server Running on the Port ${process.env.PORT || 4000}`)
);
