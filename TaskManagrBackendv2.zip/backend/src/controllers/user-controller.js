import User from "../models/user-model.js";
import logger from "../shared/logger/logger.js";
import { generateToken } from "../shared/utils/jwt-util.js";
import {
  comparePassword,
  hashPassword,
} from "../shared/utils/password-util.js";
import {
  errorResponse,
  successResponse,
} from "../shared/utils/response-util.js";

export const userController = {
  async register(req, res) {
    try {
      const { email, password, name } = req.body;
      const hashedPassword = await hashPassword(password);
      const user = new User({ email, password: hashedPassword, name });
      await user.save();
      const token = generateToken(user._id);
      logger.info("New User Registered : ", email);
      successResponse(res, { user, token }, 201);
    } catch (err) {
      logger.error("Registration Error", err);
      errorResponse(res, err);
    }
  },

  async login(req, res) {
    try {
      const { email, password } = req.body;
      const user = await User.findOne({ email });
      console.log(user);
      if (!user || !(await comparePassword(password, user.password))) {
        errorResponse(res, "Invalid Credentials", 400);
      }
      const token = generateToken(user._id);
      successResponse(res, { user, token, msg: "Login Succesfull" }, 200);
    } catch (err) {
      errorResponse(res, err);
    }
  },

  async getProfile(req, res) {
    successResponse(res, req.user);
  },

  async updateProfile(req, res) {
    try {
      const updates = Object.keys(req.body);
      const allowedUpdates = ["name", "email", "password"];
      const isValidOperation = updates.every((update) =>
        allowedUpdates.includes(update)
      );
      if (!isValidOperation) {
        throw new Error("Invalid Operation");
      }

      const user = req.user;
      console.log(user, "sjhgjhsjhsgshj");
      if (req.body.password) {
        req.body.password = await hashPassword(req.body.password);
      }
      updates.forEach((update) => (user[update] = req.body[update]));
      await user.save();

      logger.info("User Profile Updated: ", user.email);
      successResponse(res, user);
    } catch (err) {
      logger.error("Profile Update Error: ", err);
      errorResponse(res, err);
    }
  },
};
