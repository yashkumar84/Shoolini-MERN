import Task from "../models/task-model.js";
import logger from "../shared/logger/logger.js";
import {
  errorResponse,
  successResponse,
} from "../shared/utils/response-util.js";

export const taskController = {
  async createTask(req, res) {
    try {
      const task = new Task({
        ...req.body,
        owner: req.user._id,
        is_deleted: false,
      });
      await task.save();
      logger.info(`New Task Created By User : ${req.user.email}`);
      successResponse(res, task, 201);
    } catch (err) {
      logger.error("task Creation Error ", err);
      errorResponse(res, err);
    }
  },

  async getTask(req, res) {
    try {
      const tasks = await Task.find({ owner: req.user._id });
      successResponse(res, tasks);
    } catch (err) {
      logger.error("Error in Fetching Tasks ", err);
      errorResponse(res, err);
    }
  },

  async getTaskById(req, res) {
    try {
      const task = await Task.findOne({
        _id: req.params.id,
        owner: req.user._id,
      });
      if (!task) {
        return errorResponse(res, "Task Not Found", 404);
      }
      successResponse(res, task);
    } catch (err) {
      logger.error("Error in Finding Task By Id : ", err);
      errorResponse(res, err);
    }
  },

  async updateTask(req, res) {
    try {
      const updates = Object.keys(req.body);
      const allowedUpdates = [
        "title",
        "description",
        "status",
        "dueDate",
        "color",
        "priority",
      ];
      const isValidOperation = updates.every((update) =>
        allowedUpdates.includes(update)
      );
      if (!isValidOperation) {
        throw new Error("Invalid Operation");
      }

      const task = await Task.findOne({
        _id: req.params.id,
        owner: req.user._id,
      });
      if (!task) {
        return errorResponse(res, "Task Not Found ", 404);
      }

      updates.forEach((update) => (task[update] = req.body[update]));
      await task.save();

      logger.info("Task Updated: ", task.title);
      successResponse(res, task);
    } catch (err) {
      logger.error("Task Update Error ", err);
      errorResponse(res, err);
    }
  },

  async deleteTask(req, res) {
    try {
      const task = await Task.findOne({
        _id: req.params.id,
        owner: req.user._id,
      });

      if (!task) {
        return errorResponse(res, "Task Not Found ", 404);
      }
      task.is_deleted = true;
      await task.save();
      logger.info("Task Deleted ", task.title);
      successResponse(res, task);
    } catch (err) {
      logger.error("Task Deletion Error: ", err);
      errorResponse(res, err);
    }
  },
};
