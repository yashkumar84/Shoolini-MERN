export const userService = {
  async register(req , res ){
      
  }
}