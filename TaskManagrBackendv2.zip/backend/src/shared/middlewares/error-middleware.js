import { errorResponse } from "../utils/response-util";

const errorHandler = (err, req, res, next) => {
  errorResponse(res, err, 500);
};
