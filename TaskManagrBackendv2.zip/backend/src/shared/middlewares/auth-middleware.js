import User from "../../models/user-model.js";
import { verifyToken } from "../utils/jwt-util.js";
import { errorResponse } from "../utils/response-util.js";

export const auth = async (req, res, next) => {
  try {
    const token = req.header("Authorization").replace("Bearer ", "");
    const decoded = verifyToken(token);
    const user = await User.findOne({ _id: decoded.userId });

    if (!user) {
      throw new Error("User Not Found");
    }
    console.log(user, "This is the user");
    req.user = user;
    req.token = token;
    next();
  } catch (err) {
    errorResponse(res, "Please Authenticate ", 401);
  }
};
