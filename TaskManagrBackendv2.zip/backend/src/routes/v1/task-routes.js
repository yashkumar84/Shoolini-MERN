import { Router } from "express";
import { taskController } from "../../controllers/task-controller.js";
import { auth } from "../../shared/middlewares/auth-middleware.js";

export const taskRouter = Router();

taskRouter.post("/", auth, taskController.createTask);
taskRouter.get("/", auth, taskController.getTask);
taskRouter.get("/:id", auth, taskController.getTaskById);
taskRouter.patch("/:id", auth, taskController.updateTask);
taskRouter.delete("/:id", auth, taskController.deleteTask);
