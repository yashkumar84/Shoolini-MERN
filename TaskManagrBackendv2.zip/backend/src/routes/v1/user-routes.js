import { Router } from "express";
import { userController } from "../../controllers/user-controller.js";
import { auth } from "../../shared/middlewares/auth-middleware.js";

export const userRouter = Router();

userRouter.post("/", userController.register);
userRouter.post("/login", userController.login);
userRouter.get("/profile", auth, userController.getProfile);
userRouter.post("/update-profile", auth, userController.updateProfile);
