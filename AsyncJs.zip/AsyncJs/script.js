//HOF

//Callback

function add(a, b) {
  console.log(a + b);
}

function result(add, a, b) {
  console.log("The answer is : ");
  add(a, b);
}

result(add, 10, 20);

const arr = [1, 2, 3, 4, 5, 6, 7];
arr.push(8);
console.log(arr);
//map

const price = [100, 200, 300, 400, 500, 600];

//['100 Rs', '200 Rs', '300 Rs','400 Rs'].....

const newPrice = price.map((ele) => "$ " + ele);
console.log(newPrice);

const filterPrice = price.filter((ele) => ele <= 400);
console.log(filterPrice);

const totalPrice = price.reduce((acc, ele) => acc + ele, 0);
console.log(totalPrice);

const element = price.find((ele) => ele == 400);
console.log(element);

const index = price.findIndex((ele) => ele == 400);
console.log(index);

console.log(price.includes(80));


const strArr = ["abc" , "jkl", "def", "jhi"]; 
