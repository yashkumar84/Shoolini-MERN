import { getData } from "../services/api-client.js";

window.addEventListener("load", initEvent);

async function initEvent() {
  const data = await getData();
  const urlSearchParams = new URLSearchParams(window.location.search);
  const productId = urlSearchParams.get("id");
  console.log(productId);
  const product = data.find((ele) => ele.id == productId);
  printData(product);
}

function printData(product) {
  const col1 = document.querySelector(".col-4");
  const col2 = document.querySelector(".col-5");
  const row1 = document.querySelector(".row1");
  const row2 = document.querySelector(".row2");
  const img = document.createElement("img");
  const col3 = document.querySelector(".col3");
  const col4 = document.querySelector(".col4");
  img.src = product.img;
  img.alt = "No Image";
  img.style.height = "700px";
  img.style.width = "400px";
  col1.append(img);
  const title = document.createElement("h2");
  title.innerText = product.title;
  const desc = document.createElement("p");
  desc.innerText = product.description;
  row1.append(title, desc);
  title.style.marginTop = "200px";
  const addToCartButton = document.createElement("button");
  addToCartButton.classList = "btn btn-success";
  addToCartButton.innerText = "Add To Cart";
  const buyButton = document.createElement("button");
  buyButton.classList = "btn btn-primary";
  buyButton.innerText = "Buy";
  col3.append(addToCartButton);
  col4.append(buyButton);
}
