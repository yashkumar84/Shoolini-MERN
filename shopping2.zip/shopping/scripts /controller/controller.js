import { getData } from "../services/api-client.js";

console.log("Hello Js is Running");

window.addEventListener("load", init);
let data;
async function init() {
  data = await getData();
  data.map((product) => printCard(product));

  // printCarousel();
}

// function printCarousel() {
//   let carousel = `<div id="carouselExampleFade" class="carousel slide carousel-fade">
//   <div class="carousel-inner">
//     <div class="carousel-item active">
//       <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" alt="...">
//     </div>
//     <div class="carousel-item">
//       <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" class="d-block w-100" alt="...">
//     </div>
//     <div class="carousel-item">
//       <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" class="d-block w-100" alt="...">
//     </div>
//   </div>
//   <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
//     <span class="carousel-control-prev-icon" aria-hidden="true"></span>
//     <span class="visually-hidden">Previous</span>
//   </button>
//   <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
//     <span class="carousel-control-next-icon" aria-hidden="true"></span>
//     <span class="visually-hidden">Next</span>
//   </button>
// </div>`;
//   let container = document.querySelector(".container-1");
//   console.log(container);
//   // container.innerHTML += carousel;
// }

function printCard(item) {
  const h5 = document.createElement("h5");
  h5.className = "card-title";
  h5.innerText = item.title.substring(0, 20) + "...";
  const p = document.createElement("p");
  p.className = "card-text";
  p.innerText = item.description.substring(0, 90) + "...";
  const h4 = document.createElement("h4");
  h4.classList = "card-title";
  h4.innerText = `₹ ${item.price}`;
  const a = document.createElement("a");
  a.classList = "btn btn-primary";
  a.href = "#";
  a.innerText = "Buy Now";
  const cardBody = document.createElement("div");
  cardBody.classList = "card-body";
  cardBody.appendChild(h5);
  cardBody.appendChild(p);
  cardBody.appendChild(h4);
  cardBody.appendChild(a);
  const img = document.createElement("img");
  img.classList = "card-img-top";
  img.alt = "No Image";
  img.src = item.img;
  img.style.height = "200px";
  const card = document.createElement("div");
  card.classList = "card";
  card.style.width = "18rem";
  card.style.height = "500px";
  card.onclick = () => {
    location.href = `http://127.0.0.1:5500/shopping/product-details.html?id=${item.id}`;
  };
  card.append(img, cardBody);
  const cardDiv = document.querySelector(".cards");
  cardDiv.style.gap = "10px";
  cardDiv.append(card);
}
