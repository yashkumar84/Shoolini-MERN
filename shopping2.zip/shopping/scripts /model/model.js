// function Product(id, title, image, description) {
//   this.id = id;
//   this.title = title;
//   this.img = image;
//   this.description = description;
// }
export class Product {
  constructor(id, title, image, price, description) {
    this.id = id;
    this.title = title;
    this.img = image;
    this.description = description;
    this.price = price;
  }
}
