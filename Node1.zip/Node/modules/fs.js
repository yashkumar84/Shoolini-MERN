// const { readFile } = require("node:fs/promises");
// const { resolve } = require("node:path");
// async function logFile() {
//   try {
//     const filePath = resolve("./package.json");
//     const contents = await readFile(filePath, { encoding: "utf8" });
//     console.log(contents);
//   } catch (err) {
//     console.error(err.message);
//   }
// }
// logFile();
import fs from "fs";
import path from "path";

async function printFile() {
  fs.readFile("./package.json", (err, data) => {
    if (err) {
      console.log("Error Occurs");
      return;
    }
    console.log("Data is ", data.toString());
  });
}

printFile();
