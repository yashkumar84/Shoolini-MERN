// Hoisting --- Declaration on top

// First class Citizen 

// function 

// function  are like the Objects

function add(){

}

const add1 = function(){

}

const add2 = function(fn){
  return fn;
}