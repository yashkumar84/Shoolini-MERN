console.log("Hello js Is Working");

const div = document.querySelector(".container");
console.log(div);

const h1 = document.createElement("h1");
h1.innerText = "My name is Yash";
h1.classList = "name name1";

div.appendChild(h1);

//BOM (Browser Object Model)

console.log("Local Storage is ", localStorage);
console.log("Session Storage is ", sessionStorage);
console.log(location);
// setTimeout(() => {
//   location.href = "https://www.flipkart.com/";
// }, 5000);

console.log(navigator);
