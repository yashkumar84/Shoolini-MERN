import { getData } from "../services/api-client.js";

console.log("Hello Js is Running");

window.addEventListener("load", init);
let data;
async function init() {
  data = await getData();
  data.map((product) => printCard(product));

  // printCarousel();
}

// function printCarousel() {
//   let carousel = `<div id="carouselExampleFade" class="carousel slide carousel-fade">
//   <div class="carousel-inner">
//     <div class="carousel-item active">
//       <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" alt="...">
//     </div>
//     <div class="carousel-item">
//       <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" class="d-block w-100" alt="...">
//     </div>
//     <div class="carousel-item">
//       <img src="https://thehouseofrare.com/cdn/shop/products/IMG_0180_f6c0cc37-6ce6-4d0b-82ac-fd550ecd4ada_765x.jpg?v=1709534074" class="d-block w-100" class="d-block w-100" alt="...">
//     </div>
//   </div>
//   <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
//     <span class="carousel-control-prev-icon" aria-hidden="true"></span>
//     <span class="visually-hidden">Previous</span>
//   </button>
//   <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
//     <span class="carousel-control-next-icon" aria-hidden="true"></span>
//     <span class="visually-hidden">Next</span>
//   </button>
// </div>`;
//   let container = document.querySelector(".container-1");
//   console.log(container);
//   // container.innerHTML += carousel;
// }

// function payments() {
//   var options = {
//     key: "rzp_test_vH9aiPgVuYOFFO", // Enter the Key ID generated from the Dashboard
//     amount: 50000, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
//     currency: "INR",
//     name: "Shopping ", //your business name
//     description: "Test Transaction",

//     order_id: "order_PBAuNnmNbOWOHX", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
//     handler: function (response) {
//       alert(response.razorpay_payment_id);
//       alert(response.razorpay_order_id);
//       alert(response.razorpay_signature);
//     },
//     prefill: {
//       //We recommend using the prefill parameter to auto-fill customer's contact information, especially their phone number
//       name: "Yash Kumar", //your customer's name
//       email: "yash.kumar@example.com",
//       contact: "9000090000", //Provide the customer's phone number for better conversion rates
//     },
//     notes: {
//       address: "Shopping Corporate Office",
//     },
//     theme: {
//       color: "#3399cc",
//     },
//   };
//   var rzp1 = new Razorpay(options);
//   rzp1.on("payment.failed", function (response) {
//     alert(response.error.code);
//     alert(response.error.description);
//     alert(response.error.source);
//     alert(response.error.step);
//     alert(response.error.reason);
//     alert(response.error.metadata.order_id);
//     alert(response.error.metadata.payment_id);
//   });
//   document.querySelector(".buy").onclick = function (e) {
//     console.log("hello");
//     rzp1.open();
//     e.preventDefault();
//   };
// }
function printCard(item) {
  const h5 = document.createElement("h5");
  h5.className = "card-title";
  h5.innerText = item.title.substring(0, 20) + "...";
  const p = document.createElement("p");
  p.className = "card-text";
  p.innerText = item.description.substring(0, 90) + "...";
  const h4 = document.createElement("h4");
  h4.classList = "card-title";
  h4.innerText = `₹ ${item.price}`;
  const a = document.createElement("a");
  a.classList = "btn btn-primary buy";
  a.innerText = "Buy Now";
  a.onclick = () => payments();
  const cardBody = document.createElement("div");
  cardBody.classList = "card-body";
  cardBody.appendChild(h5);
  cardBody.appendChild(p);
  cardBody.appendChild(h4);
  cardBody.appendChild(a);
  const img = document.createElement("img");
  img.classList = "card-img-top";
  img.alt = "No Image";
  img.src = item.img;
  img.style.height = "200px";
  const card = document.createElement("div");
  card.classList = "card";
  card.style.width = "18rem";
  card.style.height = "500px";
  img.onclick = () => {
    location.href = `http://127.0.0.1:5500/shopping/product-details.html?id=${item.id}`;
  };
  card.append(img, cardBody);
  const cardDiv = document.querySelector(".cards");
  cardDiv.style.gap = "10px";
  cardDiv.append(card);
}
