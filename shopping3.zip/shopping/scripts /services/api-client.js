import { Product } from "../model/model.js";

export async function getData() {
  let response = await fetch("https://fakestoreapi.com/products");
  let data = await response.json();
  data = data.map(
    (product) =>
      new Product(
        product.id,
        product.title,
        product.image,
        product.price,
        product.description
      )
  );
  console.log(data);
  return data;
}
