import { useState } from "react";

import "./App.css";
import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Nav from "./components/Nav";
import Products from "./pages/Products";
import Login from "./components/Login";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminDashboard from "./pages/AdminDashboard";
import Unauthorised from "./pages/Unauthorised";
import UserDashBoard from "./pages/UserdashBoard";

function App() {
  const [names, setNames] = useState([
    "Yash",
    "Aryan",
    "Aman",
    "Rohit",
    "Mohit",
  ]);
  const [isLoggedin, setIsLoggedin] = useState(true);
  // return <>{isLoggedin ? <h1>Logged in </h1> : <h1>Not Logged in </h1>}</>;
  // return (
  //   <>
  //     {names.map((name, index) => (
  //       <h1 key={index}>{name}</h1>
  //     ))}
  //   </>
  // );

  return (
    <>
      <Nav />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/products" element={<Products />} />
        <Route path="/login" element={<Login />} />
        <Route path="/unauthorised" element={<Unauthorised />} />
        <Route path="/admindashboard" element={<AdminDashboard />} />
        <Route path="/userdashboard" element={<UserDashBoard />} />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute
              isAuthenticated={true}
              allowedRoles={["admin", "user"]}
              userRole={"admin"}
            >
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
      </Routes>
    </>
  );
}

export default App;
