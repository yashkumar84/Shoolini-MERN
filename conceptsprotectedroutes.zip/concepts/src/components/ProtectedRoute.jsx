import { Navigate } from "react-router-dom";

const ProtectedRoute = ({
  isAuthenticated,
  allowedRoles,
  userRole,
  children,
}) => {
  if (!isAuthenticated) {
    return <Navigate to={"/login"} />;
  }

  // if (!allowedRoles.includes(userRole)) {
  //   return <Navigate to={"/unauthorised"} />;
  // }

  if (userRole === "admin") {
    if (!allowedRoles.includes(userRole)) {
      return <Navigate to={"/unauthorised"} />;
    }
    return <Navigate to={"/admindashboard"} />;
  }
  if (userRole === "user") {
    if (!allowedRoles.includes(userRole)) {
      return <Navigate to={"/unauthorised"} />;
    }
    return <Navigate to={"/userdashboard"} />;
  }
  return <Navigate to={"/unauthorised"} />;
};

export default ProtectedRoute;
