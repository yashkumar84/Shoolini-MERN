const About = () => {
  return <div style={{ color: "white" }}>About</div>;
};

export default About;
