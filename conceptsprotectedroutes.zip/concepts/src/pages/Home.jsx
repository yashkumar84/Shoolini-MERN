const Home = () => {
  console.log("Home");
  return <div style={{ color: "white" }}>Home</div>;
};

export default Home;
