const Unauthorised = () => {
  return <div>Unauthorised</div>;
};

export default Unauthorised;
