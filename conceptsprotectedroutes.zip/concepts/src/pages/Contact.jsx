const Contact = () => {
  return <div style={{ color: "white" }}>Contact</div>;
};

export default Contact;
