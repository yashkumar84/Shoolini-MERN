// var arr = [1,2,3,4,5];

// for(var i = 0;i<arr.length;i++){
//   console.log(arr[i]);
// }

// let , var and const

// let a = [1,2,3,4,5];
// for(let ele of a){
//   console.log(ele)
// }

// {
//   let b = 10;
//   b = 70;
//   console.log(b);
// }
// {
//   let c ;

//   const d =  10;
//   const b = 10;
//   console.log(b);
// }

// console.log(b);

// const a = [1,2,3,6,7,8];
// // a = [3,4,5]
// a.splice(3,0,4,5);
// console.log(a);

//Objects ------

// const marks = [10, 20, 30, 40, 50, 60, 70];

// const dhoni = {
//   name: "MS Dhoni",
//   age: 40,
//   six: 600,
//   century: 800,
// };

// console.log(dhoni.century);

// dhoni.address = "Jharkhand";
// dhoni[4] = 1200;
// console.log(dhoni[4]);

// dhoni["height"] = 6;

// let weight = "weight";

// dhoni[weight] = 80;

// console.log(dhoni["height"]);
// console.log(dhoni[weight]);

// delete dhoni.address;

// console.log(dhoni);
// // 4 : 800

// const yashResult = {

// }

// const aryanResult ={

// }

// functions

// Reduce the Repetation in code

let a = 10;
let b = 20;
let c = a + b;

let d = 90;
let e = 80;
let f = d + e;
//Normal Function
function add(a, b) {
  return a + b;
}

function printName(name) {
  console.log(name);
}

console.log(add(20, 30));
console.log(add(10, 20));

// Anonymous Function -- Those Functions Which Do not have any name ---

const sub = function (a, b) {
  return a - b;
};

console.log(sub(20, 10));

//IIFE -- Immediate Invoked Function Expression

(function (a, b) {
  console.log(a + b);
})(10, 20);

//You have To make A function which takes the n arguments and give you the output after that all Numbers........

// 10,20 -- 30
// 30 , 49 -- 79
//50,10,10,20,30 -- 120

function addMany() {
  let sum = 0;
  for (let i = 0; i < arguments.length; i++) {
    sum += arguments[i];
  }

  return sum;
}

console.log(addMany(10, 20, 30, 40, 50, "50", "Yash"));

//Arrow Functions
//Shorthand Functions

let arrowAdd = (a, b) => a + b;

console.log(arrowAdd(10,30));


let moreThanOneLineArrowFunction = (a , b)=> {
      console.log(a +b);
      console.log("Yash");
      return a + b;
}