import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import { Route, Routes } from "react-router-dom";
import UserPage from "./modules/user/pages/UserPage";
import TaskPage from "./modules/task/pages/TaskPage";
import DashBoard from "./modules/dashboard/DashBoard";

function App() {
  return (
    <>
      <DashBoard />
      <Routes>
        <Route path="user" element={<UserPage />} />
        <Route path="task" element={<TaskPage />} />
      </Routes>
    </>
  );
}

export default App;
