const UserPage = () => {
  return <div>UserPage</div>;
};

export default UserPage;
