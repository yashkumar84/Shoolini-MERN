import { ChevronDown, ListTodo, PlusCircle, User } from "lucide-react";

const DashBoard = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/*Nav Bar */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <ListTodo className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">
                TaskFlow
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-600 hover:text-gray-800 px-3 py-2 rounded-md text-sm font-medium">
                Tasks
              </button>

              <div className="relative ">
                <button className="flex items-center space-x-2 text-gray-600 hover:text-gray-800">
                  <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <User size={20} className="text-blue-600" />
                  </div>
                  <ChevronDown size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">
                Welcome Back User!
              </h1>
              <p className="mt-2 text-gray-600 ">
                Here's An Overview Of Your Tasks
              </p>
            </div>
            <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200">
              <PlusCircle size={20} />
              <span>Add New task</span>
            </button>
          </div>
        </div>

        
      </main>
    </div>
  );
};

export default DashBoard;
