const Output = ({ text }) => {
  return <div>{text}</div>;
};

export default Output;
