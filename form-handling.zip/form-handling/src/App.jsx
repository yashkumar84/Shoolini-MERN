import "./App.css";
import LoginPage from "./pages/LoginPage";

function App() {
  return (
    <>
      <LoginPage />
    </>
  );
}

export default App;
