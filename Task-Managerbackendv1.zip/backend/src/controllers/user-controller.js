import User from "../models/user-model.js";
import logger from "../shared/logger/logger.js";
import { generateToken } from "../shared/utils/jwt-util.js";
import { hashPassword } from "../shared/utils/password-util.js";
import {
  errorResponse,
  successResponse,
} from "../shared/utils/response-util.js";

export const userController = {
  async register(req, res) {
    try {
      const { email, password, name } = req.body;
      const hashedPassword = await hashPassword(password);
      const user = new User({ email, password: hashedPassword, name });
      await user.save();
      const token = generateToken(user._id);
      logger.info("New User Registered : ", email);
      successResponse(res, { user, token }, 201);
    } catch (err) {
      logger.error("Registration Error", err);
      errorResponse(res, err);
    }
  },
};
