import User from "../../models/user-model";
import { verifyToken } from "../utils/jwt-util";
import { errorResponse } from "../utils/response-util";

export const auth = async (req, res, next) => {
  try {
    const token = req.header("Authorization").replace("Bearer ", "");
    const decoded = verifyToken(token);
    const user = await User.findOne({ _id: decoded.userId });

    if (!user) {
      throw new Error("User Not Found");
    }

    req.user = user;
    req.token = token;
    next();
  } catch (err) {
    errorResponse(res, "Please Authenticate ", 401);
  }
};
