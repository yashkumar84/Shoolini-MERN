import { errorResponse } from "../utils/response-util";

export const validateRequest = (schema) => {
  return (req, res, next) => {
    try {
      const { error } = schema.validate(req.body);
      if (error) {
        return errorResponse(res, error.details[0].message, 400);
      }
    } catch (err) {
      next(err);
    }
  };
};
