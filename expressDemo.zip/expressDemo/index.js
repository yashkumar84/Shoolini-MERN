import express from "express";
import mongoose from "mongoose";
import { userRouter } from "./routes.js";

const app = express();

app.listen(1234, () => {
  console.log("App is Running on the Port 1234");
});
const dbUrl =
  "mongodb+srv://dangerouscodecrew:KZ3cFVgv6lFzCRdT@cluster0.ek5rid3.mongodb.net/task-manager?retryWrites=true&w=majority&appName=Cluster0";
mongoose
  .connect(dbUrl)
  .then(() => console.log("Connection Established"))
  .catch((err) => console.log("SOme Error"));

app.use("/photo", express.static("./public"));
app.use(express.json());

const loggerMiddleWare = (req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
};

app.use(loggerMiddleWare);

app.use("/user", userRouter);

app.get("/", loggerMiddleWare, (req, res) => {
  res.json({
    msg: "Hi Application is Running on the PORT 1234",
    data: "Hello This is the JSON Data and for the testing purpose only",
  });
});

app.get("/photo", (req, res) => {
  res.sendFile(
    "/Users/amantyagi/Desktop/Shoolini Mern/Node/expressDemo/public/download.jpeg"
  );
});

app.post("/", (req, res) => {
  const data = req.body;
  console.log(data);
  res.json(data);
});
