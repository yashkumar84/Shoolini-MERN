import { Router } from "express";

export const userRouter = Router();

userRouter.get("/", (req, res) => {
  const { q } = req.query;
  res.send(`Hello User ${q}`);
});

userRouter.get("/:id", (req, res) => {
  console.log("Request Coming");
  const { id } = req.params;
  res.send(id);
});
