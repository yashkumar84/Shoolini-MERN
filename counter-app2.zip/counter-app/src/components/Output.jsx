import "./css/Output.css";

const Output = ({ text }) => {
  return (
    <div className="output">
      <h1>{text}</h1>
    </div>
  );
};

export default Output;
