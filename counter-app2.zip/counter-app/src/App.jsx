import { useState } from "react";
import Button from "./components/Button";
import Output from "./components/Output";
import "./App.css";

function App() {
  console.log("App Function Call");
  const [count, setCount] = useState(0);

  const plus = () => {
    setCount(count + 1);
  };
  const minus = () => {
    if (count > 0) {
      setCount(count - 1);
    }
  };
  return (
    <div className="root">
      <Output text={count} />
      <div className="buttons">
        <Button text="-" fn={minus} />
        <Button text={"+"} fn={plus} />
      </div>
    </div>
  );
}

export default App;
